# Tetapkan sebuah daftar dari hash-hash kedalam variable `exams`


# Cetak element pada indeks 1

exams=[
  {subject:"Matematika",score:80},
  {subject:"Ilmu Pengetahuan Alam",score:55}
  ]
  
  puts exams[1]
  
