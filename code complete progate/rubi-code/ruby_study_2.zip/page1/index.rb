# Tetapkan sebuah daftar dari bahasa-bahasa pada variable `languages`
languages=["Jepang","Inggris","Spanyol"]
  puts languages
# Cetak variable `languages`

