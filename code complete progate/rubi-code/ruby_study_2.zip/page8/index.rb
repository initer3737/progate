# Tulis ulang hash berikut ini dengan menggunakan penyingkatan sintaks
exam = {subject: "Matematika", score: 80}

puts "Nilai skor #{exam[:subject]} adalah #{exam[:score]}"
