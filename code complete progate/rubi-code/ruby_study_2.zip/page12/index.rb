exams = [
  {subject: "Matematika", score: 80},
  {subject: "Ilmu Pengetahuan Alam", score: 55}
]

# Cetak nilai dari element dengan simbol :score pada indeks 1
exam=exams[1][:score]
puts exam