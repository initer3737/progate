text = "Mari belajar pemrograman"

# Gabungkan variable text dan string yang telah diberikan, lalu cetak hasilnya
puts  text+"menggunakan Progate"

length = 8
width = 9

# Cetak hasil dari perkalian length * width
puts length*width
