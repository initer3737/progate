length = 9
width = 8
puts width
puts length * width
puts "----"

# Perbarui variable width dengan 13
width=13

puts width
puts length * width