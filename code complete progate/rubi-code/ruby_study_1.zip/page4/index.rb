# Cetak hasil dari 13 dikali 9
puts 13*9

# Cetak hasil dari 32 dibagi 8
puts 32/8

# Cetak hasil sisa dari 18 dibagi 5
puts 18%5
