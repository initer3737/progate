require "./menu"

class Drink < Menu
end
