require "./menu"

class Drink < Menu
  # Tambahkan variable instance `volume`
  attr_accessor:volume
end
