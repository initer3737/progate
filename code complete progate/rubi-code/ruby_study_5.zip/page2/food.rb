# Lakukan `import` dari `menu.rb` menggunakan `require`
require './menu'

# Definisikan class `Food` yang mewarisi class `Menu`
class Food<Menu
end