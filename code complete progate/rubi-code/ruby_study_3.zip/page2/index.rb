# Definisikan method print_info
def print_info
puts "Selamat datang di Toko Elektronik Ninja!"
  puts "Headphone-headphone sedang diskon hari ini!"
end #metod

# Panggil method print_info 
print_info
