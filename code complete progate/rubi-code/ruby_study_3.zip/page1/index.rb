def introduce
  puts "Halo"
  puts "Saya adalah Ninja Ken"
  # Print "Saya berusia 14 tahun"
  puts "Saya berusia 14 tahun"
end

puts "-----Perkenalan diri-----"
# Panggil method introduce
introduce
