<?php
// Deklarasikan class Review 
class Review{
  private $menuName;
  private $body; 
      public function __construct($menuName,$body)
        {
          $this->body=$body;
          $this->menuName=$menuName;
        }
  public function getBody(){return $this->body;}
  public function getMenuName(){return $this->menuName;}
}

?>