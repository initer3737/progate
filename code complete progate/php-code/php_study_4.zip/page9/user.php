<?php
// Definisikan class User
class User{
  private $gender;
  private $name;
  
  public function __construct($name,$gender)
  {
    $this->gender=$gender;
    $this->name=$name;
  }
  
  public function getName(){return $this->name;}
  public function getGender(){return $this->gender;}
}

?>