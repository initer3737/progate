<?php
$price = 10;
$taxRate = 0.08;
echo 'Nilai $price: '.$price;
echo '<br>';
echo 'Nilai $taxRate: '.$taxRate;
echo '<br>';
echo '-----';
echo '<br>';

// Ketik code Anda dibawah
$result=($price * $taxRate)+$price;
echo "Harga setelah pajak adalah $$result" ;

?>