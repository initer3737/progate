<?php
$menus = array(
  array('name' => 'GULAI', 'price' => 9),
  array('name' => 'PASTA', 'price' => 12),
  array('name' => 'KOPI', 'price' => 6)
);

// Ketik code Anda dibawah
$nilai=0;
$item_max='';
$price_max=0;
foreach ($menus as $menu)
{
    $harga=$menu['price'];
  echo $menu['name'].' berharga $'.$harga;
  echo "<br>";
  $nilai+=$harga;
    if($harga > $price_max){
      $price_max=$harga;
      $item_max=$menu['name'];
    }
}
echo " Harga item termahal adalah $item_max dengan harga $$price_max";
//echo "Harga total adalah $$nilai";
?>