<?php
$name = 'Tom';
echo 'Nilai $name: '.$name;
echo '<br>';
echo '-----';
echo '<br>';

// Ketik code Anda dibawah
echo "Nama saya adalah $name";

?>