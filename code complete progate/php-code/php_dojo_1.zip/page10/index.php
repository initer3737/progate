<?php
$menus = array(
  array('name' => 'GULAI', 'price' => 9),
  array('name' => 'PASTA', 'price' => 12),
  array('name' => 'KOPI', 'price' => 6)
);

// Ketik code Anda dibawah
$nilai=0;
foreach ($menus as $menu)
{
    $harga=$menu['price'];
  echo $menu['name'].' berharga $'.$harga;
  echo "<br>";
  $nilai+=$harga;
    
}
echo "Harga total adalah $$nilai";
?>