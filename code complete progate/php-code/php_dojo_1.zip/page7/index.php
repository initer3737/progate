<?php
$prices = array(10, 6, 7, 8);
echo 'Nilai $prices: ';
foreach ( $prices as $price ) {
  echo $price.' ';
}
echo '<br>';
echo '-----';
echo '<br>';

// Ketik code Anda dibawah
$itemTotal=0;
foreach( $prices as $item ) {
  echo "$item<br>";
    
      
}

$maku=max($prices);
    echo "Harga termahal adalah $$maku";  
?>