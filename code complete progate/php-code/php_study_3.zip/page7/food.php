<?php 
require_once('menu.php');

class Food extends Menu {
  
}

?>