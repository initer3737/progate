import { dog1, dog2 } from "./data/dogData";
import chalk from "chalk";
console.log("---------");
dog1.info();
console.log("---------");
dog2.info();