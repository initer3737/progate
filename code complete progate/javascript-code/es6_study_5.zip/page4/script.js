// Tulis ulang code dibawah and import constant dog1 dan dog2
import {dog1,dog2} from "./dogData";

// Salin code di jendela instruksi dan tulis ulang constant dog1 dan dog2 agar dapat dicetak
// dog.info();
dog1.info();
console.log("------------");
dog2.info();