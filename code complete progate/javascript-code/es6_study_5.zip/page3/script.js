// Hapus code dibawah

// Import constant dog
import dog from "./dogData"; 

dog.info();