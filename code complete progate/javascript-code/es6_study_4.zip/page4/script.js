class Animal {
  // Tambahkan constructor
  constructor(){
    console.log("Membuat instance baru");
  }
}

const animal = new Animal();
