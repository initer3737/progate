class Animal {
}

// Tetapkan instance class Animal ke constant animal
const animal=new Animal();
  console.log(animal);
// Tampilkan nilai milik constant animal

