class Animal {
  constructor() {
    // Tetapkan nilai string「Leo」ke property name
    this.name="Leo";
    
    // Tetapkan nilai「3」ke property age
    this.age=3;
  }
}

const animal = new Animal();
console.log(`Nama: ${animal.name}`);
// Print「Nama: ____」
console.log(`Usia:${animal.age}`);

// Print「Usia: __」

