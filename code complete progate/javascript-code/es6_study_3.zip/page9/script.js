const number1 = 103;
const number2 = 72;
const number3 = 189;

// Ketik sebuah function getMax untuk mendapatkan nilai maksimum
const getMax=(a,b,c)=>{
let maku=a;
  if(b<c){
    maku=c;
  }else{
    maku=b;
  }
  return maku;
}

// Print "Nilai maksimum adalah __"
console.log(`Nilai maksimum adalah ${getMax(number1,number2,number3)}`);
