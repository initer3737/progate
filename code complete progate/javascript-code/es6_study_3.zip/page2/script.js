// Tetapkan function ke constant hello
const hello=function(){
  console.log("Halo!");
  console.log("Saya Ninja ken");
};


// Panggil function yang ditetapkan di constant hello
hello();
