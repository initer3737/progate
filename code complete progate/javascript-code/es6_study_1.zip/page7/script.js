// Deklarasikan variable length
let length=5;
console.log(length);

// Cetak nilai variable length


// Gunakan variable length untuk mencetak hasil area lingkaran
console.log(length*length*3);
