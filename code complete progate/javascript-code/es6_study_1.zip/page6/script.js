// Deklarasikan nama variable dengan nilai string "Ninja Ken"
let name="Ninja Ken";
console.log(name);

// Cetakan nilai nama variable

