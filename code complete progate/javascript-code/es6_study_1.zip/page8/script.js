let name = "Ninja Ken";
console.log(name);

// Update nilai variable ke "Birdie"
name="Birdie";

// Cetak nilai dari variable name
console.log(name);
