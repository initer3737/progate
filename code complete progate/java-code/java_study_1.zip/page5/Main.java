class Main {
  public static void main(String[] args) {
    // Gabungkan dan cetak "Hello" dan "World"
    System.out.println("Hello"+"World");
    
    // Gabungkan dan cetak "38" dan "19"
    System.out.println("38"+"19");
    
    // Jumlahkan dan cetak 38 dan 19
    System.out.println(38+19);
    
  }
}

