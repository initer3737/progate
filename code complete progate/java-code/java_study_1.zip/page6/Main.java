class Main {
  public static void main(String[] args) {
    // Deklarasikan variable number dengan tipe int
    int number;
    
    // Tetapkan 3 ke variable number
    number=3;
    
    // Cetak variable number
    System.out.println(number);
    
    // Deklarasikan variable name dengan tipe String
    String name;
    
    // Tetapkan "Bob" ke variable name 
    name="Bob";
    
    // Cetak variable name 
    System.out.println(name);
    
    
  }
}
