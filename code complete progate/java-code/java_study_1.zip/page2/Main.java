class Main {
  public static void main(String[] args) {
    
    //Baris ini seharusnya adalah komentar
    
    // Cetak "Hello Java"
    System.out.println("Hello Java");
    
  }
}

