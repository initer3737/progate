class Main {
  public static void main(String[] args) {
    // Cetak hasil 12 dibagi 3
    System.out.println(12/3);
    
    // Cetak hasil 3 dikali 6
    System.out.println(3*6);
    
    // Cetak sisah dari 8 dibagi 3
    System.out.println(8%3);
    
  }
}
