// Wariskan class Vehicle
class Bicycle extends Vehicle {
  
}