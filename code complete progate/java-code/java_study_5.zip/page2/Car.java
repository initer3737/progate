// Wariskan class Vehicle
class Car extends Vehicle {
 
}