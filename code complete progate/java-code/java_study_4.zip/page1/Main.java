class Main {
  public static void main(String[] args) {
    Person person1 = new Person("Murni Aminah");
    Person person2 = new Person("Yahya Nasrun Rizal");

    person1.hello();
    person2.hello();
  }
}
