// Definisikan class `Person`
class Person{
  
}
