class Main {
  public static void main(String[] args) {
    // Tetapkan sebuah instance baru dari class `Person` pada variable `person1`
    Person person1=new Person();
    
    // Tetapkan sebuah instance baru dari class `Person` pada variable `person2`
    Person person2=new Person();
    
  }
}
