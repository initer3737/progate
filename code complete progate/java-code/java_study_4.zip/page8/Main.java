class Main {
  public static void main(String[] args) {
    // Buatlah sebuah instance dari `Person` dengan "Murni Aminah" sebagai argument-nya
    Person person1 = new Person("Murni Aminah");
    person1.hello();

    // Buatlah sebuah instance dari `Person` dengan "Yahya Nasrun Rizal" sebagai argument-nya
    Person person2 = new Person("Yahya Nasrun Rizal");
    person2.hello();
  }
}
