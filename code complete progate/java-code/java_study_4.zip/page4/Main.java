class Main {
  public static void main(String[] args) {
    Person person1 = new Person();
    // Panggil method `hello` menggunakan instance `person1`
    person1.hello();
    
    Person person2 = new Person();
    // Panggil method `hello` menggunakan instance `person2`
    person2.hello();
    
  }
}
