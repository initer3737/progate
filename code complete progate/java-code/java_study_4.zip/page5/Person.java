class Person {
  // Deklarasikan field instance `name`
      //properti
  public String name;

  public void hello() {
    System.out.println("Hello");
  }
}
