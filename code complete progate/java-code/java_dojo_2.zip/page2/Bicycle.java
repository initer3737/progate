class Bicycle{
    private String name;
  Bicycle(String name)
  {
    this.name=name;
  }
    public String getName()
    {
      return this.name;
    }
}