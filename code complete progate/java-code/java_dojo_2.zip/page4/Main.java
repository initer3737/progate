class Main {
  public static void main(String[] args) {
    Bicycle bicycle=new Bicycle("Bianchi","Hijau",0);
     System.out.println("【Info Sepeda】"); 
        bicycle.printData();
  }
}