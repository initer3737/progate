import java.util.Scanner;
class Main {
  public static void main(String[] args) {
      Scanner scanner =new Scanner(System.in);
    Bicycle bicycle=new Bicycle("Bianchi","Hijau",0);
     System.out.println("【Info Sepeda】"); 
        bicycle.printData();
     System.out.println("-----------------");
     System.out.println("Masukkan jarak yang akan ditempuh: ");
        int jarak=scanner.nextInt();
      bicycle.run(jarak);
      System.out.println("=================");
      //===============================
      System.out.println("【Info Mobil】");
  Car car=new Car("Ferrari","Merah");
  car.printData();
  }
}

