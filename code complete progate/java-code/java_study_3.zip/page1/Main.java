class Main {
  public static void main(String[] args) {
    hello();
  }
  
  public static void hello() {
    // Ubah "Hello World" dengan "Hello Java"
    System.out.println("Hello Java");
  }
}
