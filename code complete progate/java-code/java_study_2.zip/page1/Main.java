class Main {
  public static void main(String[] args) {
    // Cetak true
    System.out.println(true);
    
    // Cetak false
    System.out.println(false);
    
    // Bandingkan nilai menggunakan == dan cetak hasilnya
    System.out.println(12/4==3);
    
    // Bandingkan nilai menggunakan != dan cetak hasilnya
    System.out.println(12/4!=3);  
    
    // Deklarasikan variable bool bertipe boolean, dan tetapkan hasil 3 * 9 == 27 kepadanya
    boolean bool=3*9 == 27;
    
    // Cetak nilai dari variable bool
    System.out.println(bool);
    
  }
}
