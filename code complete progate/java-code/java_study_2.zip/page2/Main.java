class Main {
  public static void main(String[] args) {
    // Bandingkan 8 dan 5 dengan < atau > untuk mencetak false
    System.out.println(8<5);
    
    // Bandingkan 3 dan 2 dengan <= atau >= untuk mencetak true
    System.out.println(3>=2);
    
  }
}
