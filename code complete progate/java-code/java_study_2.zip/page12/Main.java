class Main {
  public static void main(String[] args) {
    // Tetapkan daftar bahasa ke variable languages
    String[] languages={"Ruby", "PHP", "Python"};
    
    // Cetak element index 1
    System.out.println(languages[1]);
    
    // Perbarui element index 1 ke "Java"
    languages[1] ="Java";
    
    // Cetak element index 1
    System.out.println(languages[1]);
    
  }
}