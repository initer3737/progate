class Main {
  public static void main(String[] args) {
    String[] names = {"Bob", "Kate", "John"};
    
    // Dapatkan element names menggunakan enhanced loop for, dan cetak "Nama saya adalah ____"    
    for(String name:names)
    {
      System.out.println("Nama saya adalah " +name);
    }
  }
}