class Main {
  public static void main(String[] args) {
    // Gunakan && atau || untuk mencetak true
    System.out.println(true || false);
    
    // Gunakan && atau || untuk mencetak false
    System.out.println(false && true);
    
    // Cetak hasil dari 8 < 5 DAN 3 >= 2
    System.out.println(8 < 5 && 3 >= 2);
    
    // Cetak hasil dari 8 < 5 ATAU 3 >= 2
    System.out.println(8 < 5 || 3 >= 2);
    
    // Cetak hasil yang BUKAN 8 < 5
    System.out.println( !(8 < 5) );
    
  }
}