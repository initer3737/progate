/*
Dibawah "FROM purchases" tambahkan code untuk mengambil baris dengan
nilai "makanan" dikolom "category" 
*/
select * from purchases where category="makanan"; 
SELECT *
FROM purchases
