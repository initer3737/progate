-- Akses kolom "name" dari tabel "purchases" 
select name from purchases;
