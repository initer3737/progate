-- Akses kolom "price" dari table "purchases"
select price from purchases;


