-- dapatkan total jumlah dari kolom price
SELECT sum(price)
FROM purchases
;