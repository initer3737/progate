-- dapatkan total berdasarkan tanggal dan karakter dimana totalnya lebih dari 30
SELECT sum(price),character_name
FROM purchases
GROUP BY character_name
having sum(price)>30
;
