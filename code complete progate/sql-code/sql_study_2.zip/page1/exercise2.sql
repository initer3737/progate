-- dapatkan baris dari kolom character_name dengan duplikat dihilangkan
SELECT distinct(character_name)
FROM purchases;