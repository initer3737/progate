-- dapatkan harga terendah dikolom price
SELECT min(price)
FROM purchases;