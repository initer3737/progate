-- dapatkan nilai rata-rata dari kolom price
SELECT AVG(PRICE)
FROM purchases;