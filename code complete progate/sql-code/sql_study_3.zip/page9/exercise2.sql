select players.name AS "nama pemain",teams.name AS "tim(tahun lalu)"
from players
left join teams
on players.previous_team_id = teams.id
;