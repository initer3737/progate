-- Gunakan AS untuk menamai kolom "total skor tim"
SELECT sum(goals) as "total skor tim"
FROM players
;