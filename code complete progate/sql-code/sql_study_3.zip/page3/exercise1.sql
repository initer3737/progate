-- Gunakan AS untuk menamai kolom "180 cm atau lebih"
SELECT name as "180 cm atau lebih "
FROM players
where height>=180 ;