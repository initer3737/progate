SELECT players.name AS "nama pemain" , players.height AS "tinggi pemain"
FROM players where height > (select avg(height) from players   )
;