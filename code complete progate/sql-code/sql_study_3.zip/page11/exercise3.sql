select countries.name AS "nama negara" , avg(goals) AS "skor rata-rata"
from players
join countries
on players.country_id = countries.id
group by countries.name;