-- Tambahkan data ke tabel students
insert into students (name,course) values("Kate","Java");

-- Jangan menghapus kueri dibawah
select * from students;
