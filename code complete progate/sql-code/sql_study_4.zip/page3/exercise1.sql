-- Hapus data yang ber-id 7 di tabel student
delete from students where id=7;
-- Jangan hapus kueri dibawah
SELECT * FROM students;
