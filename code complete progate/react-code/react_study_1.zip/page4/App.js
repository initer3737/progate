import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div>
        <h1>Hello World</h1>
        <p>Ayo belajar React bersama-sama!</p>
        {/* Gunakan tag <img> untuk menampilkan gambar */}
       <img src="https://s3-ap-northeast-1.amazonaws.com/progate/shared/images/lesson/react/kentheninja.png"/>
      </div>
    );
  }
}

export default App;
